
===================================
REQUIREMENTS TO RUN THE PROJECT
===================================

1. Apache Flex SDK Installer source

	Download the source from https://github.com/apache/flex-utilities/tree/develop/flex-installer 
	to link in ApacheFlexSDKInstallerLib project