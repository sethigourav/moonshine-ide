//
//  ViewController.swift
//  ElCapitanSandboxTest
//
//  Created by Santanu Karar on 17/06/16.
//  Copyright © 2016 Santanu Karar. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet weak var lblFileSelectedNotif: NSTextField!
    @IBOutlet weak var txtConsole: NSScrollView!
    
    var selectedCodeFile: NSURL!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // adding scrollable textview
        let ed = NSTextView(frame: NSMakeRect(0, 0, view.frame.width, view.frame.height))
        ed.font = NSFont(name:"Helvetica", size:13)
        ed.editable = false
        ed.selectable = true
        ed.verticallyResizable = true
        ed.horizontallyResizable = false
        ed.autoresizingMask = [NSAutoresizingMaskOptions.ViewWidthSizable, NSAutoresizingMaskOptions.ViewHeightSizable]
        ed.textContainer?.widthTracksTextView = true
        
        txtConsole.documentView = ed
    }

    override var representedObject: AnyObject?
    {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    func updateConsoleView(value:String)
    {
        (txtConsole.documentView as! NSTextView).string?.appendContentsOf("\n" + value)
    }
    
    func checkCodeFileExistence() -> Bool
    {
        if selectedCodeFile == nil
        {
            let alert = NSAlert()
            alert.messageText = "Error!"
            alert.informativeText = "Please select a code file to proceed"
            alert.addButtonWithTitle("OK")
            alert.alertStyle = NSAlertStyle.WarningAlertStyle
            alert.runModal()
            
            return false
        }
        
        return true
    }
    
    func runShellScript(exePath:String, arg:[String], commandToPrint:String)
    {
        let task = NSTask()
        task.launchPath = exePath
        task.arguments = arg
        
        let pipe = NSPipe()
        let errorPipe = NSPipe()
        task.standardOutput = pipe
        task.standardError = errorPipe
        updateConsoleView(commandToPrint)
        task.launch()
        
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let output = NSString(data: data, encoding: NSUTF8StringEncoding)
        
        let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
        let errorOutput = NSString(data: errorData, encoding: NSUTF8StringEncoding)
        
        updateConsoleView((errorOutput == "") ? output as! String : errorOutput as! String)
    }

    @IBAction func onBrowseSHFile(sender: AnyObject)
    {
        let openDlg = NSOpenPanel()
        openDlg.canChooseFiles = true
        openDlg.canCreateDirectories = false
        openDlg.showsHiddenFiles = true
        openDlg.allowsMultipleSelection = false
        
        let resultInt: Int = openDlg.runModal()
        if resultInt == NSFileHandlingPanelCancelButton
        {
            return
        }
        
        lblFileSelectedNotif.stringValue = "√ Code file selected"
        selectedCodeFile = openDlg.URL
    }
    
    @IBAction func onRunMount(sender: AnyObject)
    {
        runShellScript("/bin/bash", arg: ["-c", "mount"], commandToPrint: "$ mount")
    }
    
    @IBAction func onRunSHDirect(sender: AnyObject)
    {
        // probable termination
        guard checkCodeFileExistence() else
        {
            return
        }
        
        let runCom = "chmod 744 " + selectedCodeFile.path! + "&& " + selectedCodeFile.path!
        runShellScript("/bin/sh", arg: ["-c", runCom], commandToPrint: "$ " + runCom)
    }
    
    @IBAction func onRunSHbyAS(sender: AnyObject)
    {
        // probable termination
        guard checkCodeFileExistence() else
        {
            return
        }
        
        let scptPath = NSBundle.mainBundle().pathForResource("TestRun", ofType: "scpt")
        runShellScript("/usr/bin/osascript", arg: [scptPath!, selectedCodeFile.path!], commandToPrint: "$ " + scptPath! + " " + selectedCodeFile.path!)
    }
}